$(function(){
    $('.hd_inner .toggle').click(function(){
        $('.toggle_menu').fadeToggle()
        $('.logo_img').attr("src", "../IMG/img/logo/logo_color.png")
        $('.toggle>span').css("color", "#19459d")
    })

})

$(function(){
    $('.next').click(function(){
        $('.back_slide').animate({marignLeft: -100 + '%'}, 1000, function () {
            $('.back_slide>li').eq(0).appendTo('.back_slide')
            $('.back_slide').css({marignLeft: 0})

            let nth = $(this).index()+1

            $('.ex_sub').removeClass('on')
            $('.ex_sub').eq(nth).addClass('on')
            $('.ex_sub img').attr('src',`../IMG/img/background/experience_slide_${nth}.jpg`)

        })
    })
    
    $('.prev').click(function(){
        $('.back_slide').animate({marignLeft: 100 + '%'}, 1000, function () {
            $('.back_slide>li').eq(-1).prependTo('.back_slide')
            $('.back_slide').css({marignLeft: 0})
        })
    })
})

$(function(){
    $('.next2').click(function(){
        $('.sec5_list').animate({marignLeft: -100 + '%'}, 1000, function () {
            $('.sec5_list>li').eq(0).appendTo('.sec5_list')
            $('.sec5_list').css({marignLeft: 0})
        })
    })
    
    $('.prev2').click(function(){
        $('.sec5_list').animate({marignLeft: 100 + '%'}, 1000, function () {
            $('.sec5_list>li').eq(-1).prependTo('.sec5_list')
            $('.sec5_list').css({marignLeft: 0})
        })
    })
})


$(function(){
    $('.next').click(function(){
        let nth = $('.ex_sub').index()+1

        $('ex_sub').removeClass('.on')
        $('ex_sub').eq(nth).addClass('.on')
    })
})